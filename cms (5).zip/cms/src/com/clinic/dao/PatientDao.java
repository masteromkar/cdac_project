package com.clinic.dao;

import java.util.List;

import com.clinic.dto.Patient;

public interface PatientDao {
	
	int insertPatient(Patient p);
	
	String patientStatus(Patient p);
	
	List<Patient> allpatient();
	
	public Patient selectPatient(int pId);
	

	void updatePatient(Patient patient);
	
	void deletepatient(int pid);
	
	
	
	
}
