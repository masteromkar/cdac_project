package com.clinic.dao;

import java.util.List;

import com.clinic.dto.Doctor;

public interface DoctorDao {
	void insertDoctor(Doctor dr);
	boolean checkDoctor(Doctor dr);
	List<Doctor> allDoctor();
}
