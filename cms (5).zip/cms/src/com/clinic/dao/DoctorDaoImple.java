package com.clinic.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.clinic.dto.Doctor;


@Repository
public class DoctorDaoImple implements DoctorDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Override
	public void insertDoctor(Doctor dr) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(dr);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}

	@Override
	public boolean checkDoctor(Doctor dr) {
		boolean b = hibernateTemplate.execute(new HibernateCallback<Boolean>() {

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Doctor where dr_username = ? and dr_pass = ?");
				q.setString(0, dr.getUserName());
				q.setString(1, dr.getDrPass());
				@SuppressWarnings("unchecked")
				List<Doctor> li = q.list();
				
				boolean flag = !li.isEmpty();
					dr.setDrId(li.get(0).getDrId());
					dr.setDrName(li.get(0).getDrName());
				tr.commit();
				session.flush();
				session.close();
				return flag;
			}
			
		});
		return b;
	}

	@Override
	public List<Doctor> allDoctor() {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		List<Doctor> b = hibernateTemplate.execute(new HibernateCallback<List<Doctor>>() {

		
			@Override
			public List<Doctor> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Doctor");
				@SuppressWarnings("unchecked")	
				List<Doctor> li = q.list();
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		System.out.println(b);
		return b;
	}



}
