package com.clinic.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.clinic.dto.Patient;

@Repository
public class PatientDaoImple implements PatientDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Override
	public int insertPatient(Patient p) {
		
		    if(p.getpStatus()==null) {
		    	p.setpStatus("Waiting...");
		    }
		
		  int pid=  hibernateTemplate.execute(new HibernateCallback<Integer>() {

			@Override
			public Integer doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(p);
				tr.commit();
				session.flush();
				session.close();
				return p.getpId();
			}
			
		});
		  
		  return pid;
		
	}

	@Override
	public String patientStatus(Patient p) {
		String b = hibernateTemplate.execute(new HibernateCallback<String>() {

			@Override
			public String doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Patient where pId=?");
				q.setInteger(0, p.getpId());
		
				@SuppressWarnings("unchecked")
				List<Patient> li = q.list();
				tr.commit();
				session.flush();
				session.close();
				
				if(li.isEmpty()) {
					return "Patient entry is Not Available";
				}
				else {
					return (li.get(0)).getpStatus();
				}
			}
			
		});
		return b;
	}

	@Override
	public List<Patient> allpatient() {

		 List<Patient> b = hibernateTemplate.execute(new HibernateCallback< List<Patient>>() {

			@Override
			public  List<Patient> doInHibernate(Session session) throws HibernateException {
				System.out.println("oooooooooooooooooooooooooooooooooooooooooooooooooooooooo");
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Patient where pStatus=?");
				q.setString(0, "Waiting...");
		
				@SuppressWarnings("unchecked")
				List<Patient> li = q.list();
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return b;
	}
	
	
	@Override
	public Patient selectPatient(int pId) {
		Patient p = hibernateTemplate.execute(new HibernateCallback<Patient>() {

			@Override
			public Patient doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				//Patient ex = (Patient)session.get(Patient.class, pId);
				Query q = session.createQuery("from Patient where pId=?");
				q.setInteger(0, pId);
				

				@SuppressWarnings("unchecked")
				
				List<Patient> li =q.list();
				tr.commit();
				session.flush();
				session.close();
				return li.get(0);
			}
			
		});
		return p;

}



	@Override
	public void updatePatient(Patient patient) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				
				Patient ex = (Patient)session.get(Patient.class, patient.getpId());
				ex.setpStatus(patient.getpStatus());				
				session.update(patient);
				
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public void deletepatient(int pid) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new Patient(pid));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}




}