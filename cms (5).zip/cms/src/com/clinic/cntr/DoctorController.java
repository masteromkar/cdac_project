package com.clinic.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.context.request.WebRequest;

import com.clinic.dto.Doctor;
import com.clinic.dto.Patient;
import com.clinic.service.DoctorServ;
import com.clinic.service.PatientServ;
import com.clinic.valid.DoctorValidator;
import com.clinic.valid.LoginValidator;

@Controller
public class DoctorController {
	
	@Autowired
	private PatientServ pService;
	
	@Autowired
	private DoctorServ drService;
	
	@Autowired
	private DoctorValidator drValidator;
	
	@Autowired
	private LoginValidator logVal;
	
	@RequestMapping(value = "/prep_reg_form.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("dr", new Doctor());
		return "reg_form";
	}
	
	
	@RequestMapping(value = "/reg.htm",method = RequestMethod.POST)
	public String register(Doctor dr,ModelMap map) {
	/*	drValidator.validate(dr, result);
		if(result.hasErrors()) {
			map.put("dr", new Doctor());
			return "reg_form";
		}
		
*/		drService.addDoctor(dr);
		return "index";
	}
	
	@RequestMapping(value = "/prep_log_form.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("dr", new Doctor());
		return "login_form";
	}
	
	@RequestMapping(value = "/login.htm",method = RequestMethod.POST)
	public String login(@ModelAttribute Doctor dr,ModelMap map, HttpSession session,SessionStatus status) {
		if(!status.isComplete()) {
		
		/*logVal.validate(dr, result);
		if(result.hasErrors()) {
			map.put("dr", new Doctor());
			return "login_form";
		}*/
		boolean b = drService.findDoctor(dr);
		if(b) {
			System.out.println(dr);
			session.setAttribute("dr", dr); 
			
			return "home";
		}else {
			map.put("dr", new Doctor());
			return "login_form";
		} 
		}else {
			session.setAttribute("dr", new Doctor()); 
			map.put("dr", dr);
			return "login_form";
		}
 	}
	
	
	@RequestMapping(value = "/logout.htm",method = RequestMethod.GET)
	public String logout(@ModelAttribute Doctor dr,HttpSession session,ModelMap map,SessionStatus status,WebRequest request) {
		 status.setComplete();
		 request.removeAttribute("dr", WebRequest.SCOPE_SESSION);
		return "index";
	}
	
	
	
	@RequestMapping(value = "/patient_list.htm",method = RequestMethod.GET)
		public String patientlist(ModelMap map) {
		
		
		List<Patient> plist=pService.patientList();
		System.out.println(plist);
		map.put("PList",plist);
	
		return "Watting_patient_info";
	}
	
	@RequestMapping(value = "/approve.htm",method = RequestMethod.GET)
	public String patientUpdateForm(@RequestParam int pId,ModelMap map,HttpSession session) {
		
		Patient p = pService.findPatient(pId);
	System.out.println(p+"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		session.setAttribute("pm", p);
	
		map.put("pstate", new Patient());
		
		return "approve_list";
	}
	
	
	@RequestMapping(value ="/set_status.htm",method = RequestMethod.POST)
public String setStatus(ModelMap map ,HttpSession session,Patient p) {
		
		Patient patient = ((Patient)session.getAttribute("pm"));
		patient.setpStatus(p.getpStatus());
		pService.modifyExpense(patient);
		
		List<Patient> plist=pService.patientList();
		System.out.println(plist);
		map.put("PList",plist);
	
		return "Watting_patient_info";
	 
	}
	
	@RequestMapping(value = "/delete.htm",method = RequestMethod.GET)
	public String patientForm(@RequestParam int pId,ModelMap map,HttpSession session) {
		
		pService.removePatient(pId); 
		
		List<Patient> plist=pService.patientList();
		System.out.println(plist);
		map.put("PList",plist);
		return "Watting_patient_info";
	}
	
}
	

