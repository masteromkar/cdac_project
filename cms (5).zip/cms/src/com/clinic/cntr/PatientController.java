package com.clinic.cntr;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.clinic.dto.Doctor;
import com.clinic.dto.Patient;
import com.clinic.service.DoctorServ;
import com.clinic.service.PatientServ;
import com.clinic.valid.PatientValidator;

@Controller
public class PatientController {
	
	@Autowired
	private PatientServ pservice;
	
	@Autowired
	private DoctorServ dservice;
	
	private PatientValidator pval;
 
	@RequestMapping(value = "/patient_reg_form.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("p", new Patient());
		System.out.println("patiomn-------------------------------------------------");
	    List<Doctor> DRlist=(List<Doctor>) dservice.listDoctor();
	    System.out.println(DRlist);
    	map.put("DrList",DRlist);
		return "patient_reg_from";
	}
	
	@RequestMapping(value = "/patient_reg.htm",method = RequestMethod.POST)
	public String register(Patient p,ModelMap map) {
	/*	pval.validate(p, result);
		if(result.hasErrors()) {
			map.put("p", new Patient());
			System.out.println("patiomn-------------------------------------------------");
		    List<Doctor> DRlist=(List<Doctor>) dservice.listDoctor();
		    System.out.println(DRlist);
	    	map.put("DrList",DRlist);
			return "patient_reg_from";
		}
		*/System.out.println(p);
		int regno= pservice.addPatient(p);
		map.put("regNo", regno);
		return "patient_registration";
	}
	
	@RequestMapping(value = "/patient_status_form.htm",method = RequestMethod.GET)
	public String prepstatusForm(ModelMap map) {
		map.put("pt", new Patient());
		return "patient_status";
	}
	
	
	@RequestMapping(value = "/check_Status.htm",method = RequestMethod.POST)
	public String checkStatus(Patient p,ModelMap map) {
		String status= pservice.checkPatient(p);
		map.put("Status", status);
		map.put("pName", p.getpName());
		return "patient_status_application";
	}
	
	
	
	
}
