package com.clinic.valid;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.clinic.dto.Doctor;

@Service
public class LoginValidator implements Validator {
	
	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Doctor.class);
	}

	@Override
	public void validate(Object target,Errors errors) {
		
		Doctor login = (Doctor) target;
		
		
		if(login.getUserName().isEmpty()) {
			errors.rejectValue("userName", "unm", "insert User Name");
		}
		
		//password
		if(!login.getDrPass().isEmpty())
				{
					String pass=login.getDrPass();
					
					String passRegex="[a-zA-Z0-9]*";
					Pattern passPat=Pattern.compile(passRegex);
					Matcher matcher=passPat.matcher(pass);
					if(!matcher.matches())
					{
						System.out.println("=======================================");
						errors.rejectValue("drPass", "passKey", "password is invalid");
					}
				}else {
					
					System.out.println("+++++++++++++++++++++++++++++++++++++++++");
					errors.rejectValue("drPass", "passKey", "password is required");
				}
}
}