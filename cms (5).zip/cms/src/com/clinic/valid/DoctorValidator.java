package com.clinic.valid;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.clinic.dto.Doctor;

@Service
public class DoctorValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Doctor.class);
		
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		Doctor doctor = (Doctor) target;
		
		String drName=doctor.getDrName();
		String userName=doctor.getUserName();
		String drType=doctor.getDrType();
		if(drName.isEmpty() && userName.isEmpty() && drType.isEmpty()) {
			errors.rejectValue("drName", "unmKey", "insert Doctor Name");
			errors.rejectValue("userName", "unm", "insert User Name");
			errors.rejectValue("drType", "typekey", "insert Doctor type");
		}
		
		//password
		if(!doctor.getDrPass().isEmpty())
		{
			String pass=doctor.getDrPass();
			
			String passRegex="[a-zA-Z0-9]*";
			Pattern passPat=Pattern.compile(passRegex);
			Matcher matcher=passPat.matcher(pass);
			if(!matcher.matches())
			{
				System.out.println("=======================================");
				errors.rejectValue("drPass", "passKey", "password is invalid");
			}
		}else {
			
			System.out.println("+++++++++++++++++++++++++++++++++++++++++");
			errors.rejectValue("drPass", "passKey", "password is required");
		}
		
		

		
}
}