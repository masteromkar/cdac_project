package com.clinic.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import org.springframework.validation.Validator;

import com.clinic.dto.Patient;

@Service
public class PatientValidator implements Validator {
	
	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Patient.class);
	}

	@Override
	public void validate(Object target,Errors errors) {
		
		Patient patient = (Patient) target;
	
	
	String pName=patient.getpName();
	String pAge=patient.getpAge();
	String pHist=patient.getpHist();
	String pDis=patient.getpDis();
	
	if(pName.isEmpty() && pAge.isEmpty() && pHist.isEmpty() && pDis.isEmpty()) {
		errors.rejectValue("pName", "nameKey", "insert Patient Name");
		errors.rejectValue("pAge", "agekey", "insert Patient Age");
		errors.rejectValue("pHist", "histkey", "insert Patient History");
		errors.rejectValue("pDis", "diskey", "insert Patient disease");
		
	}
}
}
