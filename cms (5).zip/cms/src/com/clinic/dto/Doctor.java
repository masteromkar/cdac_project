package com.clinic.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "doctor")
public class Doctor {
		@Id
		@GeneratedValue
		@Column(name = "dr_id")
		private int drId;
		
		@Column(name = "dr_name")
		private String drName;
		
		@Column(name = "dr_pass")
		private String drPass;
		
		@Column(name = "dr_type")
		private String drType;
		
		@Column(name = "dr_username")
		private String userName;
		
		
		public Doctor() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		
		public Doctor(int drId, String drName, String drPass, String drType, String userName) {
			super();
			this.drId = drId;
			this.drName = drName;
			this.drPass = drPass;
			this.drType = drType;
			this.userName = userName;
		}
		public int getDrId() {
			return drId;
		}
		public void setDrId(int drId) {
			this.drId = drId;
		}
		public String getDrName() {
			return drName;
		}
		public void setDrName(String drName) {
			this.drName = drName;
		}
		public String getDrPass() {
			return drPass;
		}
		public void setDrPass(String drPass) {
			this.drPass = drPass;
		}
		public String getDrType() {
			return drType;
		}
		public void setDrType(String drType) {
			this.drType = drType;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}


		@Override
		public String toString() {
			return "Doctor [drId=" + drId + ", drName=" + drName + ", drPass=" + drPass + ", drType=" + drType
					+ ", userName=" + userName + "]";
		}
		
		
		
		
}
