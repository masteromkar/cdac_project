package com.clinic.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "patient")

public class Patient {
	
	@Id
	@GeneratedValue
	@Column(name = "p_id")
	private int pId;
	
	@Column(name="p_Name")
	private String pName;

	@Column(name="p_Age")
	private String pAge;

	@Column(name="p_Gender")
	private String pGender;

	@Column(name="p_History")
	private String pHist;

	@Column(name="p_Disease")
	private String pDis;
	

	@Column(name="p_Status")
	private String pStatus;
	
	@Column(name="dr_id")
	private int drId;

	public Patient() {
		
	}

	public Patient(int pId) {
	
		this.pId = pId;
	}

	public Patient(int pId, String pName, String pAge, String pGender, String pHist, String pDis, String pStatus ,int drId) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.pAge = pAge;
		this.pGender = pGender;
		this.pHist = pHist;
		this.pDis = pDis;
		this.pStatus = pStatus;
		this.drId=drId;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public String getpAge() {
		return pAge;
	}

	public void setpAge(String pAge) {
		this.pAge = pAge;
	}

	public String getpGender() {
		return pGender;
	}

	public void setpGender(String pGender) {
		this.pGender = pGender;
	}

	public String getpHist() {
		return pHist;
	}

	public void setpHist(String pHist) {
		this.pHist = pHist;
	}

	public String getpDis() {
		return pDis;
	}

	public void setpDis(String pDis) {
		this.pDis = pDis;
	}

	public String getpStatus() {
		return pStatus;
	}

	public void setpStatus(String pStatus) {
		this.pStatus = pStatus;
	}
	

	public int getDrId() {
		return drId;
	}

	public void setDrId(int drId) {
		this.drId = drId;
	}

	@Override
	public String toString() {
		return "Patient [pId=" + pId + ", pName=" + pName + ", pAge=" + pAge + ", pGender=" + pGender + ", pHist="
				+ pHist + ", pDis=" + pDis + ", pStatus=" + pStatus + ", drId=" + drId + "]";
	}


	
	
}
