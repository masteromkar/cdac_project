package com.clinic.service;

import java.util.List;

import com.clinic.dto.Doctor;

public interface DoctorServ {
	void addDoctor(Doctor dr);
	boolean findDoctor(Doctor dr);
	List<Doctor> listDoctor();
}
