package com.clinic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clinic.dao.DoctorDao;
import com.clinic.dto.Doctor;

@Service
public class DoctorServImple implements DoctorServ{
	
	@Autowired
	private DoctorDao drDao;
	
	@Override
	public void addDoctor(Doctor dr) {
		drDao.insertDoctor(dr);
		
	}

	@Override
	public boolean findDoctor(Doctor dr) {
		return drDao.checkDoctor(dr);
	}

	@Override
	public List<Doctor> listDoctor() {
		return drDao.allDoctor();
	}

}
