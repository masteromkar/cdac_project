package com.clinic.service;

import java.util.List;

import com.clinic.dto.Patient;

public interface PatientServ {
	 
	int addPatient(Patient p);
	
	String checkPatient(Patient p);
	
	List<Patient> patientList();
	
	Patient findPatient(int pID);

	void modifyExpense(Patient patient);
	
	void removePatient(int pid);
}
