package com.clinic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clinic.dao.PatientDao;
import com.clinic.dto.Patient;

@Service
public class PatientServImple implements PatientServ {

	@Autowired
	private PatientDao pDao;
	
	@Override
	public int addPatient(Patient p) {
		return pDao.insertPatient(p);
	}

	@Override
	public String checkPatient(Patient p) {
		return pDao.patientStatus(p);
	}

	@Override
	public List<Patient> patientList() {
		return pDao.allpatient();
	}

	@Override
	public Patient findPatient(int pID) {
		return pDao.selectPatient(pID);
	}

	@Override
	public void modifyExpense(Patient patient) {
		 pDao.updatePatient(patient);
		 
		 }

	@Override
	public void removePatient(int pid) {
		pDao.deletepatient(pid);
		
	}

}
